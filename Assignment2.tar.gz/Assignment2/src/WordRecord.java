

/**
 *
 * @author FLDCLA001
 *Outlines the behaviour of the words that will trickle down the screen. When the array of WordRecord objects is instantiated before the user begins to play, the words array is filled with WordRecord objects. This class provides the word objects of the GUI with text as well as position and speed. Provides methods that will allow the position and word to be changed.
 */
public class WordRecord {
/**
 *The String value of the text contained by the WordRecord on the screen
 */
	private String text;
/**
 *The x coordinate of the word on the screen
 */
	private  int x;
/**
 *The y coordinate of the word on the screen
 */
	private int y;
/**
 *The maximum y value a word can have, at which point it is considered dropped
 */
	private int maxY;
/**
 *Communicates that a word needs to be changed
 */
	private boolean dropped;
/**
 *The speed at which a word will fall down the screen
 */
	private int fallingSpeed;
/**
 *The maximum speed
 */
	private static int maxWait=15;
/**
 *The minimum speed
 */
	private static int minWait=1;

/**
 *The array of words from which the text will be chosen
 */
	public static WordDictionary dict;
	

/**
 *Constructor #1
 */
	WordRecord() {
		text="";
		x=0;
		y=0;	
		maxY=300;
		dropped=false;
		fallingSpeed=(int)(Math.random() * (maxWait-minWait)+minWait); 
	}
/**
 *Constructor #2
 */
	
	WordRecord(String text) {
		this();
		this.text=text;
	}
/**
 *Constructor #3
 */
	WordRecord(String text,int x, int maxY) {
		this(text);
		this.x=x;
		this.maxY=maxY;
	}
	
// all getters and setters must be synchronized
/**
 *Sets the object's y coordinate
 *@param the y coordinate to be placed at 
 */
	public synchronized  void setY(int y) {
		if (y>maxY) {
			y=maxY;
			dropped=true;
		}
		this.y=y;
	}

/**
 *Set's the object's x coordinate
 *@param the x coordinate to be placed at
 */
	public synchronized  void setX(int x) {
		this.x=x;
	}

/**
 *Sets the object's text to a specified word
 *@param the word the object must contain
 */
	public synchronized  void setWord(String text) {
		this.text=text;
	}
	
/**
 *Retrieves the word contained by the object
 *@return the word contained by the object
 */

	public synchronized  String getWord() {
		return text;
	}

/**
 *@return the x value of the object's position
 */
	
	public synchronized  int getX() {
		return x;
	}	

/**
 *@return the y value of the object's position
 */
	
	public synchronized  int getY() {
		return y;
	}

/**
 *@return the the maximum y value the object can occupy
 */
        
        public synchronized  int getMaxY() {
		return maxY;
	}

/**
 *@return the current speed at which the object is falling down the screen
 */
	
	public synchronized  int getSpeed() {
		return fallingSpeed;
	}

/**
 *@param the x and y values the object must change its position to
 */
	public synchronized void setPos(int x, int y) {
		setY(y);
		setX(x);
	}
	
/**
 *Resets the position of the word object to the top of the screen
 */
	public synchronized void resetPos() {
		setY(0);
	}

/**
 *Resets the word to its initial position
 *Gives the object a new word
 *Gives the object a new falling speed
 *Sets the dropped boolean to false
 */

	public synchronized void resetWord() {
		resetPos();
		text=dict.getNewWord();
		dropped=false;
		fallingSpeed=(int)(Math.random() * (maxWait-minWait)+minWait); 
	}
	
/**
 *@param inc - the fraction by which the object must be moved down the y axis
 * Sets the y coordinate of the object to the y coordinate plus the argument
 */
	public synchronized  void drop(int inc) {
		setY(y+inc);
	}

/**
 *@return the boolean stating whether or not the object has reached the maximum y position
 */
	public synchronized  boolean dropped() {
		return dropped;
	}
        
}
