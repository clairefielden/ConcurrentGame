

/**
 *
 * @author FLDCLA001
 *The user will input the name of a file when asked in the main class. This file will contain a list of words that will be used to fill and array of Strings. This WordDictionary class takes that array of Strings and turns it into a “dictionary” that will be utilized for choosing WordRecord objects. A random word will be allocated to each WordRecord before the game begins. 
 */
public class WordDictionary {
/**
*Integer stating the size of the dictionary
*/
	int size;
/**
*The String array of the words contained inside the dictionary
*/
	static String [] theDict= {"litchi","banana","apple","mango","pear","orange","strawberry",
		"cherry","lemon","apricot","peach","guava","grape","kiwi","quince","plum","prune",
		"cranberry","blueberry","rhubarb","fruit","grapefruit","kumquat","tomato","berry",
		"boysenberry","loquat","avocado"}; //default dictionary


/**
*the dictionary's constructor method #1
*@param takes in a temporary array of Strings that was derived from the file passed in by the user
*/

	WordDictionary(String [] tmp) {
		size = tmp.length;
		theDict = new String[size];
		for (int i=0;i<size;i++) {
			theDict[i] = tmp[i];
		}
		
	}
	
/**
*The dictionary's constructor method #2
*/
	WordDictionary() {
		size=theDict.length;
		
	}
	
/**
*The function choses a random word from the dictionary
*@return returns the random word chosen from the dictionary
*/
	
	public synchronized String getNewWord() {
		int wdPos= (int)(Math.random() * size);
		return theDict[wdPos];
	}
	
}
