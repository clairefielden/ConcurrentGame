

/**
 *
 * @author FLDCLA001
 *This class inherits the functionality of a JPanel and implements Runnable so that the instances can be executed by threads. This class is responsible for continuously updating the GUI, and therefore has a large impact on the user’s visual. This class also allocates each word in the words array to a thread and allows the threads to run. When this class’s run() method is exited, it means that the game is finished. 
 */
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Font;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;

//panel class is where all threads made 
public class WordPanel extends JPanel implements Runnable {
/**
 *An array of WordRecord objects that will contain the words to appear on the screen
 */
		private WordRecord[] words;
/**
 *The number of words on the screen at one time
 */
		private int noWords;
/**
 *The y position at which a word is considered "dropped"
 */
		private int maxY;


/**
 *Constructor method for the class
 *@param words, a WordRecord array containing the words to appear on the screen
 *@param maxY, the maximum value of the y position a word can have
 */
                WordPanel(WordRecord[] words, int maxY) {
			this.words=words; //will this work?
			noWords = words.length;
			this.maxY=maxY;	
		}
/**
 *run method for updating GUI
 *panel class is the visual you are constantly painting over
 *paint component method is where you put everything use can see
 * @param Graphics - the abstract base class for all graphics contexts that allow an application to draw onto components
 */
                
		public void paintComponent(Graphics g) {
		    int width = getWidth();
		    int height = getHeight();
		    g.clearRect(0,0,width,height);
		    g.setColor(Color.red);
		    g.fillRect(0,maxY-10,width,height);

		    g.setColor(Color.black);
		    g.setFont(new Font("Helvetica", Font.PLAIN, 26));
		   //draw the words
		    for (int i=0;i<noWords;i++){	    	
		    	g.drawString(words[i].getWord(),words[i].getX(),words[i].getY()+20);
		    }
		  }
		
/**
 *The run method spawns the threads for the words
 *before this method is terminated, all the threads are forced to finished executing and then the end boolean is set to true
 */
                @Override
		public void run() {
                    
                    int noThreads = noWords;
                    wordThread[] thrds = new wordThread[noThreads];
                    Barrier BR = new Barrier();
                    
                    //each word needs own thread
                    for(int j = 0; j<noThreads; j++)
                    {
                        thrds[j] = new wordThread(words[j], BR);
                    }
                    //spawn new threads that will do computations - positions, score, etc
                    for(int j = 0; j<noThreads; j++)
                    {
                        thrds[j].start();
                    }
                    
                    for(int i = 0; i<noThreads; i++)
                    {
                        try {
                            thrds[i].join();
                        } catch (InterruptedException ex) {
                            Logger.getLogger(WordPanel.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                    
                    WordApp.end=true;
                    
		}
	}


