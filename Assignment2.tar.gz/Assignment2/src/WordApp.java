

/**
 *
 * @author FLDCLA001
 *This class is where all the variables used to control the GUI are instantiated. The GUI is created in this class. This class takes in the user input and stores it for the GUI to work. This class stores the words as entered by the user for the threads to check. Additionally, it allows the threads to update the score of the user on the GUI. 
 */

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileInputStream;
import java.io.IOException;


import java.util.Scanner;
import java.util.concurrent.*;
import java.util.List;
//model is separate from the view.

import java.io.FileInputStream;

import java.io.IOException;

import java.io.FileInputStream;

import java.io.IOException;

import java.awt.event.ActionEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JButton;

import javax.swing.BoxLayout;

import javax.swing.JPanel;

import javax.swing.JPanel;


public class WordApp {
//shared variables
/**
*NoWords will be the number of words on the screen at one time
*/
	static int noWords=0;
/**
*totalWords is the total amount of words allowed whilst the game is being played
*/
	public volatile static int totalWords = 0;

/**
*frameX, framY and yLimit are integer variables defining the dimensions of the GUI
*/

   	static int frameX=1000;
	static int frameY=600;
	static int yLimit=480;
        
/**
*A WordDictionary object that will define the dictionary passed in by the user
*/
        
	static WordDictionary dict = new WordDictionary(); 

/**
*And array of WordRecord objects that will contain the words chosen randomly from the dictionary
*/

	static WordRecord[] words;

/**
*The score object that will contain the missed words, caught words and total score for the user
*/

	static Score score = new Score();

/**
*the list of words that will contains the words typed by the user into the textfield of the GUI
*/

        public static List<String> wordList = new ArrayList<String>();
        
/**
*The atomic integer that will count the words as they appear on the screen to ensure they do not surpass the total amount of allowed words
*/
        public static AtomicInteger wordCounter = new AtomicInteger(0);

/**
*The wordPanel controller that will implement the GUI based on the data
*/

	static WordPanel w;


/**
*JLabels describing the variables of the score class on the GUI
*/
        public static JLabel caught, missed, scr;

/**
*The textfield in which the user will type the words they see
*/
        public static final JTextField textEntry = new JTextField("",20);



/**
*Volatile booleans that will change when the action listener of the GUI picks up that the user has pressed a button
*/
	public static volatile boolean start = false;
        public static volatile boolean end = false;
        public static volatile boolean restart = false;
        public static volatile boolean pause = false;

/**
*JFrames that will embody what the user sees
*/
        public static JFrame frame = new JFrame("WordGame"); 
        public static JFrame frame2 = new JFrame("restartMenu"); 


/**
*This method will update the score JLabels on the panel
*/
        synchronized public static void updatePanel()
    {
              String newLabel = ""; 
              newLabel = "Missed: " + score.getMissed() + "    ";
              missed.setText(newLabel);
              newLabel = "Caught: " + score.getCaught() + "    ";
              caught.setText(newLabel);
              newLabel = "Score: " + score.getScore() + "    ";
              scr.setText(newLabel);
              w.repaint();
    } 
    
/**
*This method defines what will happen whilst the user is playing the game
*/
        
        public static void playGame() throws InterruptedException
        {
            wordCounter.set(0);
            score.resetScore();
            
            start = false;
            end = false;
            pause = false;
            restart = false;
            
            setupGUI(frameX, frameY, yLimit);  
    	//Start WordPanel thread - for redrawing animation

		int x_inc=(int)frameX/noWords;
	  	//initialize shared array of current words

                
		for (int i=0;i<noWords;i++) {
			words[i]=new WordRecord(dict.getNewWord(),i*x_inc,yLimit);
		}
                
                boolean executed = false;
                
                while(end==false && wordCounter.get()<totalWords)
                {
                    if(start==true && executed ==false)
                    {
                        w.run();
                        start=false;
                        executed = true;
                    }
                }
            
        }
                
        
/**
*This method checks if any of the strings contain a word that has been entered by the user
*@param String val - the value of the word contained by the string
*@return boolean contains - whether or not the value is contained in the list
*/
        synchronized static boolean checkWordList(String val)
        {
            boolean contains = false;
            Collection <String> c = Collections.synchronizedList(wordList);
            for(int i = 0; i<c.size(); i++)
            {
                if(c.contains(val))
                {
                    c.remove(i);
                    wordList.remove(i);
                    contains = true;
                }
            }
            return contains;
        }
        
/**
*Allows the user to restart the game or quit
*@param the dimensions of the new JFrame
*/
        
        public static void restart(int frameX,int frameY,int yLimit) {
		// Frame init and dimensions
    	frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	frame2.setSize(frameX, frameY);
        JPanel g = new JPanel();
        g.setLayout(new BoxLayout(g, BoxLayout.PAGE_AXIS)); 
        g.setSize(frameX,frameY);
	
        
      JPanel txt = new JPanel();
      txt.setLayout(new BoxLayout(txt, BoxLayout.LINE_AXIS)); 
      
      scr =new JLabel("Score:" + score.getScore()+ "    ");  
      
	   txt.add(scr);
	   txt.setMaximumSize( txt.getPreferredSize() );
	   g.add(txt);
           
	   JPanel b = new JPanel();
           b.setLayout(new BoxLayout(b, BoxLayout.LINE_AXIS)); 
	   JButton restartB = new JButton("Restart");;
		
	// add the listener to the jbutton to handle the "pressed" event
		restartB.addActionListener(new ActionListener()
		{
		   public void actionPerformed(ActionEvent e)
		   {
                       restart=true;
		   }
		});
                
		JButton quitB = new JButton("Quit");;
			
				// add the listener to the jbutton to handle the "pressed" event
		quitB.addActionListener(new ActionListener()
		{
		   public void actionPerformed(ActionEvent e)
		   {
		      System.exit(0);
		   }
		});
		
		b.add(restartB);
		b.add(quitB);
		
		g.add(b);
    	
      frame2.setLocationRelativeTo(null);  // Center window on screen.
      frame2.add(g); //add contents to window
      frame2.setContentPane(g);     
       	//frame.pack();  // don't do this - packs it into small space
      frame2.setVisible(true);
	}
        
/**
*Sets up the graphical user interface
*@param the dimensions of the new JFrame
*/
        public static void setupGUI(int frameX,int frameY,int yLimit) {
        // Frame init and dimensions
    	
    	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	frame.setSize(frameX, frameY);
        JPanel g = new JPanel();
        g.setLayout(new BoxLayout(g, BoxLayout.PAGE_AXIS)); 
        g.setSize(frameX,frameY);
	
        w = new WordPanel(words,yLimit);
	w.setSize(frameX,yLimit+100);
	g.add(w); 
	    
      JPanel txt = new JPanel();
      txt.setLayout(new BoxLayout(txt, BoxLayout.LINE_AXIS)); 
      caught = new JLabel("Caught:" + score.getCaught() + "    ");
      
      
      missed =new JLabel("Missed:" + score.getMissed()+ "    ");
      
      
      scr =new JLabel("Score:" + score.getScore()+ "    ");  
      
      
           txt.add(caught);
	   txt.add(missed);
	   txt.add(scr);
    
	   
	   textEntry.addActionListener(new ActionListener()
	   {
	      public void actionPerformed(ActionEvent evt) {
	         String text = textEntry.getText();
                 wordList.add(text);
	         textEntry.setText("");
	         textEntry.requestFocus();
	      }
	   });
	   
	   txt.add(textEntry);
	   txt.setMaximumSize( txt.getPreferredSize() );
	   g.add(txt);
           
	   JPanel b = new JPanel();
           b.setLayout(new BoxLayout(b, BoxLayout.LINE_AXIS)); 
	   JButton startB = new JButton("Start");;
		
	// add the listener to the jbutton to handle the "pressed" event
        //atomic boolean, when start button clicked updated to true
		startB.addActionListener(new ActionListener()
		{
		   public void actionPerformed(ActionEvent e)
		   {
                       start=true;
                       if(pause==true)
                       {
                           pause=false;
                           try {
                               wordThread.barrier.releaseAll();
                           } catch (InterruptedException ex) {
                               Logger.getLogger(WordApp.class.getName()).log(Level.SEVERE, null, ex);
                           }
                       }
                       textEntry.requestFocus();  //return focus to the text entry field
		   }
		});
                
                JButton pauseB = new JButton("Pause");;
                
                pauseB.addActionListener(new ActionListener()
		{
		   public void actionPerformed(ActionEvent e)
		   {
                       pause=true;
                       start=false;
		   }
		});
                
                
		JButton endB = new JButton("End");;
			
				// add the listener to the jbutton to handle the "pressed" event
		endB.addActionListener(new ActionListener()
		{
		   public void actionPerformed(ActionEvent e)
		   {
		      end=true;
		   }
		});
		
		b.add(startB);
		b.add(endB);
		b.add(pauseB);
                
		g.add(b);
    	
      frame.setLocationRelativeTo(null);  // Center window on screen.
      frame.add(g); //add contents to window
      frame.setContentPane(g);     
       	//frame.pack();  // don't do this - packs it into small space
      frame.setVisible(true);
	}
    
/**
*Takes in the name of the file as entered by the user and creates an array from the contents
*@param the name of the file to be read in
*@return an array of strings containing the contents of the file
*/
   public static String[] getDictFromFile(String filename) {
		String [] dictStr = null;
		try {
			Scanner dictReader = new Scanner(new FileInputStream(filename));
			int dictLength = dictReader.nextInt();
			//System.out.println("read '" + dictLength+"'");

			dictStr=new String[dictLength];
			for (int i=0;i<dictLength;i++) {
				dictStr[i]=new String(dictReader.next());
				//System.out.println(i+ " read '" + dictStr[i]+"'"); //for checking
			}
			dictReader.close();
		} catch (IOException e) {
	        System.err.println("Problem reading file " + filename + " default dictionary will be used");
	    }
		return dictStr;
	}
	
/**
*the main method, which will begin the user interface and start the playGame() method
*/

	public static void main(String[] args) throws InterruptedException {
    	
		//deal with command line arguments
                System.out.println("Enter the total words, number of words displayed at any point, and the name of the file containing the list of words?");
		Scanner sc = new Scanner (System.in);
                String line = sc.nextLine();
                
                String[] input = line.split(" ");

                totalWords = Integer.parseInt(input[0]);  //total words to fall
		noWords=Integer.parseInt(input[1]);   // total words falling at any point
                
		if(totalWords<noWords)
                {
                    while(totalWords<noWords)
                    {
                        System.out.println("This is incorrect! Please re-enter the total words!");
                        line = sc.nextLine();
                        totalWords = Integer.parseInt(line);
                    }
                }
                
		String[] tmpDict=getDictFromFile(input[2]); //file of words
		if (tmpDict!=null)
			dict= new WordDictionary(tmpDict);
		
		WordRecord.dict=dict; //set the class dictionary for the words.
		
		words = new WordRecord[noWords];  //shared array of current words
		
                playGame();
                frame.setVisible(false);
                restart(frameX, frameY, yLimit); 
                
                while(end==true)
                {
                    if(restart==true)
                    {
                        start=true;
                        end=false;
                        restart=false;
                        playGame();
                        frame.setVisible(false);
                        restart(frameX, frameY, yLimit); 
                    }
                }
               
                
                
                
	}
}
