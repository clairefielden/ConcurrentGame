

import java.util.concurrent.atomic.AtomicInteger;

/**
 *
 * @author FLDCLA001
 *This class keeps track of the user’s score by implementing atomic integers that are incremented as the user gains “points”. This class is also used to reset the user’s score when the game is restarted. 
 */
public class Score {
/**
*Integer stating the number of words missed by the user
*
*/
	private AtomicInteger missedWords;
/**
*Integer stating the number of words caught by the user
*/
	private AtomicInteger caughtWords;
/**
*Integer stating the total score the user has in the current game
*/
	private AtomicInteger gameScore;

/**
*The constructor method for the class, where all the variables are initialized to zero
*/

	Score() {
		missedWords = new AtomicInteger(0);
		caughtWords = new AtomicInteger(0);
		gameScore = new AtomicInteger(0);
	}
		
	// all getters and setters must be synchronized

/**
*@return the number of missed words
*/
	public int getMissed() {
		return missedWords.get();
	}
	
/**
*@return the number of caught words
*/

	public int getCaught() {
		return caughtWords.get();
	}

/**
*@return the total of missed words and caught words
*/

	public int getTotal() {
		return (missedWords.get()+caughtWords.get());
	}


/**
*@return the user's total score
*/

	public int getScore() {
		return gameScore.get();
	}

/**
*Increments the number of missed words
*/

	public void missedWord() {
		missedWords.getAndIncrement();
	}

/**
*Increments the number of caught words
*Increases the gamescore by the length passed in as an argument
*@param the length of the caught word 
*/

	public synchronized void caughtWord(int length) {
		caughtWords.getAndIncrement();
		gameScore.addAndGet(length);
	}
	
/**
*Resets all the variables in the class to zero
*/

	public void resetScore() {
		caughtWords.set(0);
		missedWords.set(0);
		gameScore.set(0);
	}
}
