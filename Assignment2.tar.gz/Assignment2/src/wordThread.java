
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;

/**
 *
 * @author FLDCLA001
 *The thread class is a Runnable object because it was called from the WordPanel class.  This class controls what the threads will do whilst they are running. The threads will control the behaviour of the words travelling down the screen and will be active whist the game is being played (i.e. not ended or paused).
 */
public class wordThread extends Thread {
    
/**
 *The word that the thread contains, including the text, position and falling speed
 */
    WordRecord object;
/**
 *the barrier object that will control whether or not the thread is suspended
 */
    public static Barrier barrier;

/**
 *The constructor that will initialize the class vairables according to the arguments passed in
 *@param wr is the WordRecord object the thread will contain
 *@param barrier is the barrier object the thread will contain, and is homogenous across all threads
 */
    wordThread(WordRecord wr, Barrier barrier)
    {
        object = wr;
        this.barrier = barrier;
    }

/**
 *Changes the score displayed to the user
 *resets the word contained by the thread
 *Increments the word counter
 */
    public void changeScore()
    {
              WordApp.updatePanel();
              object.resetWord();
              WordApp.wordCounter.getAndIncrement();
    } 
           
/**
 *The method the thread will follow whilst it is executing
 * The thread moves down the screen, constantly checking if the word it contains has been typed in my the user
 *If the word is "dropped" or typed in by the user, the word encased by the thread and the Score object updated 
 *If the pause button is pressed, the barrier suspends all the threads
 *If the end button is pressed, all the threads die
 *If the wordCounter exceeds the totalWords allowed, all the threads die
 */
    public void run()
    { 
         //while loop to repaint screen entire time, while true
         //when a word changes dimensions, repaint it - Java automatically calls the paint component method
        while(WordApp.totalWords>WordApp.wordCounter.get() && WordApp.end==false)
        {
          if(WordApp.checkWordList(object.getWord()))
          {
               WordApp.score.caughtWord(object.getWord().length());
               changeScore();
          }
          object.drop(object.getSpeed());
          
          try 
          {
              TimeUnit.MILLISECONDS.sleep(50);
          } 
          catch (InterruptedException ex) 
          {
              System.out.println("Interruped!");
              this.yield();
          }
          
          WordApp.w.repaint(); 
          
          if(object.dropped() == true)
          {
              WordApp.score.missedWord();
              changeScore();
          }
          
          while(WordApp.pause == true)
          {
              try {
                  barrier.block();
              } catch (InterruptedException ex) {
                  Logger.getLogger(wordThread.class.getName()).log(Level.SEVERE, null, ex);
              }
          }
          
          }
          
          
        }
}
