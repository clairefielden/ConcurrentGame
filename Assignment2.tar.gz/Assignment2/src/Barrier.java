
/**
 *
 * @author FLDCLA001
 * When the pause button is pressed, this class allows all the threads to be “blocked”. When the start button is pressed again, all the threads are “released”. 
 */
public class Barrier {
    /**
    *A synchronized method that takes in no arguments and does not return any arguments.
    *Calls the instance method, wait(), which causes all the threads to be suspended whilst the pause volatile Boolean is true.
*/
    public synchronized void block() throws InterruptedException
    {
        wait();
    }
 
 /**
 *Synchronized method.
 * Called when the start button is pressed after the game has been paused. 
 * The notifyAll() method is called, which then awakens the threads and allows them to continue. 
 *
 */
    public synchronized void releaseAll() throws InterruptedException
    {
        notifyAll();
    }
 
}
    

